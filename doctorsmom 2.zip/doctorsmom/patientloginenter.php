<?php
include("config.php");

// Initialize the response array
$response = array();

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Assuming you have form data in variables
    $patient_id = $_POST['patient_id'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $bmi = $_POST['bmi'];
    $birthweightpregnancy = $_POST['birthweightpregnancy'];
    $chronic = $_POST['chronic'];
    $familyhistory = $_POST['familyhistory'];
    $lmp = $_POST['lmp'];
    $gestionalage = $_POST['gestionalage'];

    // Check if the patient_id already exists
    $check_sql = "SELECT * FROM `adddetailspatient` WHERE `patient_id` = '$patient_id'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        // Patient_id already exists, return an error response
        $response['success'] = false;
        $response['message'] = 'Patient ID already exists. Duplicate entries are not allowed.';
    } else {
        // Prepare and execute the SQL query
        $insert_sql = "INSERT INTO `adddetailspatient` 
                (`patient_id`, `name`, `age`, `height`, `weight`, `bmi`, `birthweightpregnancy`, `chronic`, `familyhistory`, `lmp`, `gestionalage`)
                VALUES 
                ('$patient_id', '$name', '$age', '$height', '$weight', '$bmi', '$birthweightpregnancy', '$chronic', '$familyhistory', '$lmp', '$gestionalage')";

        // Execute the query and check for success
        if ($conn->query($insert_sql) === TRUE) {
            $response['success'] = true;
            $response['message'] = 'Data inserted successfully';
        } else {
            $response['success'] = false;
            $response['message'] = 'Error inserting data: ' . $conn->error;
        }
    }
} else {
    $response['success'] = false;
    $response['message'] = 'Invalid or incomplete form data';
}

// Close the database connection
$conn->close();

// Send the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
