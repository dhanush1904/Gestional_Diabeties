<?php
include("config.php");

// Initialize response array
$response = array();

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required form fields are set for login
    if (isset($_POST['patient_id']) && isset($_POST['password'])) {
        $patient_id = $_POST['patient_id'];
        $password = $_POST['password'];

        // Check the connection for login
        if ($conn->connect_error) {
            $response['struct'] = 2;
            $response['message'] = "Connection failed: " . $conn->connect_error;
        } else {
            // Use prepared statements to prevent SQL injection for login
            $login_sql = "SELECT * FROM patientid WHERE patient_id = ? AND password = ?";
            $login_stmt = $conn->prepare($login_sql);
            $login_stmt->bind_param("ss", $patient_id, $password);
            $login_stmt->execute();
            $login_result = $login_stmt->get_result();

            $response['patient_id'] = $patient_id; // Always include patient_id in response

            if ($login_result->num_rows > 0) {
                // Fetch the row from the result for login
                $row = $login_result->fetch_assoc();

                // Check if patient details exist
                $details_sql = "SELECT * FROM `adddetailspatient` WHERE `patient_id` = ?";
                $details_stmt = $conn->prepare($details_sql);
                $details_stmt->bind_param("s", $patient_id);
                $details_stmt->execute();
                $details_result = $details_stmt->get_result();

                if ($details_result->num_rows > 0) {
                    // Both login successful and details filled
                    $response['struct'] = 1;
                    $response['message'] = "Login successful and patient details filled.";
                } else {
                    // Login successful but details not filled
                    $response['struct'] = 2;
                    $response['message'] = "Login successful but patient details not filled.";
                }
            } else {
                // Patient_id or password is incorrect
                // Check if patient details exist
                $details_sql = "SELECT * FROM `adddetailspatient` WHERE `patient_id` = ?";
                $details_stmt = $conn->prepare($details_sql);
                $details_stmt->bind_param("s", $patient_id);
                $details_stmt->execute();
                $details_result = $details_stmt->get_result();

                if ($details_result->num_rows > 0) {
                    // Invalid login but details filled
                    $response['struct'] = 3;
                    $response['message'] = "Invalid patient_id or password, but patient details filled.";
                } else {
                    // Invalid login and details not filled
                    $response['struct'] = 4;
                    $response['message'] = "Invalid patient_id or password, and patient details not filled.";
                }
            }

            $login_stmt->close(); // Close the prepared statement for login
            $details_stmt->close(); // Close the prepared statement for patient details
        }
    } else {
        $response['struct'] = 2;
        $response['message'] = "patient_id and password parameters are required in the form data for login.";
    }
} else {
    $response['struct'] = 2;
    $response['message'] = "Invalid request method. Only POST requests are allowed for login.";
}

// Close the database connection
$conn->close();

// Send the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
