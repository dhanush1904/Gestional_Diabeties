<?php
// Include the database configuration file
include("config.php");

// Initialize the response array
$response = array();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if patient_id is provided in the POST request
    if (isset($_POST['patient_id'])) {
        // Fetch data from the 'doctor_report' table based on the provided patient ID
        $patient_id = $_POST['patient_id'];
        $sql_doctor_report = "SELECT scan_name, suggestion FROM doctor_report WHERE patient_id = ?";
        $stmt_doctor_report = $conn->prepare($sql_doctor_report);
        
        // Bind parameters
        $stmt_doctor_report->bind_param("s", $patient_id);
        
        // Execute the statement
        $stmt_doctor_report->execute();
        
        // Get the result
        $result_doctor_report = $stmt_doctor_report->get_result();

        // Check if there are rows in the result
        if ($result_doctor_report->num_rows > 0) {
            // Initialize arrays to hold scan names and suggestions
            $scanNames = array();
            $suggestionNames = array();
            
            // Fetch each row and add scan names and suggestions to arrays
            while ($row_doctor_report = $result_doctor_report->fetch_assoc()) {
                $scanNames[] = $row_doctor_report['scan_name'];
                $suggestionNames[] = $row_doctor_report['suggestion'];
            }
            
            // Assign scan names and suggestions arrays to response
            $response['scanNames'] = $scanNames;
            $response['suggestionNames'] = $suggestionNames;
        } else {
            // No data found for the provided patient ID in doctor_report table
            $response['scanNames'] = array();
            $response['suggestionNames'] = array();
        }

        // Prepare and execute the SQL query to retrieve data from the 'riskview' table
        $sql_riskview = "SELECT patient_id, risk FROM `riskview` WHERE `patient_id` = ?";
        $stmt_riskview = $conn->prepare($sql_riskview);
        $stmt_riskview->bind_param("s", $patient_id);
        $stmt_riskview->execute();
        $result_riskview = $stmt_riskview->get_result();

        // Check if data is found in the 'riskview' table
        if ($result_riskview->num_rows > 0) {
            // Fetch data from the result set and store them in an array
            while($row_riskview = $result_riskview->fetch_assoc()) {
                $response['riskName'] = $row_riskview['risk'];
            }
        } else {
            // No data found for the provided patient ID in riskview table
            $response['riskName'] = "";
        }

        // Set success status
        $response['status'] = true;
        
        // Close the statements
        $stmt_doctor_report->close();
        $stmt_riskview->close();
    } else {
        // patient_id is not provided in the POST request
        $response['status'] = false;
        $response['message'] = "Please provide patient_id in the POST request.";
    }
} else {
    // Unsupported request method
    $response['status'] = false;
    $response['message'] = "Unsupported request method.";
}

// Return response as JSON
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn->close();
?>
