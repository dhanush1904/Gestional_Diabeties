<?php

include("config.php"); // Include your database connection configuration

// Initialize the response array
$response = array();

// Check if patient_id is provided in the POST request
if (isset($_POST['patient_id'])) {

    // Sanitize the input to prevent SQL injection
    $patient_id = mysqli_real_escape_string($conn, $_POST['patient_id']);

    // Select data from the database based on the provided patient_id
    $sql = "SELECT kickdate, kicktime, kickday, kickcount FROM fetal WHERE patient_id = '$patient_id'";

    $result = $conn->query($sql);

    if ($result) {
        // Check if any rows were returned
        if ($result->num_rows > 0) {
            // Fetch data and store it in the response array
            $response['success'] = true;
            $response['data'] = array();

            while ($row = $result->fetch_assoc()) {
                // Check if an entry with the same kickday and kickdate already exists
                $existingEntry = array_filter($response['data'], function ($entry) use ($row) {
                    return $entry['kickday'] == $row['kickday'] && $entry['kickdate'] == $row['kickdate'];
                });

                if (empty($existingEntry)) {
                    // If no existing entry, create a new entry
                    $CountData = array(
                        'kicktime' => $row['kicktime'],
                        'kickcount' => $row['kickcount']
                    );

                    $fetalHistory = array(
                        'kickday' => $row['kickday'],
                        'kickdate' => $row['kickdate'],
                        'isColleps' => false,  // Add isColleps field
                        'CountData' => array($CountData)
                    );

                    $response['data'][] = $fetalHistory;
                } else {
                    // If entry exists, add CountData to the existing entry
                    $existingEntryKey = key($existingEntry);
                    $CountData = array(
                        'kicktime' => $row['kicktime'],
                        'kickcount' => $row['kickcount']
                    );

                    $response['data'][$existingEntryKey]['CountData'][] = $CountData;
                }
            }
        } else {
            $response['success'] = false;
            $response['message'] = "No data found for the provided patient_id.";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Error executing query: " . $conn->error;
    }
} else {
    $response['success'] = false;
    $response['message'] = "patient_id not provided in the POST request.";
}

// Return response as JSON
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();

?>
