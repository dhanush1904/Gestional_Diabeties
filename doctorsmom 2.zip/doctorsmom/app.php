<?php
// Include the database configuration file
require 'config.php';

// Function to insert data into the 'blood' table
function insertData($patient_id, $date, $time, $day, $food, $bloodsugar, $conn) {
    $sql = "INSERT INTO blood (patient_id, date, time, day, food, bloodsugar) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $patient_id, $date, $time, $day, $food, $bloodsugar);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

// Check if data is received via POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the JSON data from the request body
    $json_data = file_get_contents('php://input');

    // Decode the JSON data
    $data = json_decode($json_data, true);

    // Check if the JSON decoding was successful and if all required keys exist
    if ($data !== null && isset($data['patient_id'], $data['date'], $data['time'], $data['day'], $data['food'], $data['bloodsugar'])) {
        // Extract data from the JSON
        $patient_id = $data['patient_id'];
        $date = $data['date'];
        $time = $data['time'];
        $day = $data['day'];
        $food = $data['food'];
        $bloodsugar = $data['bloodsugar'];

        // Insert data into the blood table
        if (insertData($patient_id, $date, $time, $day, $food, $bloodsugar, $conn)) {
            echo json_encode(array("message" => "Data inserted successfully"));
        } else {
            echo json_encode(array("message" => "Error inserting data"));
        }
    } else {
        echo json_encode(array("message" => "Invalpatient_id$patient_id or incomplete JSON data"));
    }
} else {
    // Fetch data from the 'blood' table
    $sql = "SELECT * FROM blood";
    $result = $conn->query($sql);

    // Check if there are rows in the result
    if ($result->num_rows > 0) {
        // Initialize an array to hold the data
        $data = array();

        // Fetch each row and add it to the data array
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        // Encode the entire data array as JSON and output it
        echo json_encode($data);
    } else {
        // Output a message if no rows are found
        echo json_encode(array("message" => "No data found"));
    }

    // Set the Content-Type header to indicate that JSON is being sent
    header("Content-Type: application/json");
}
?>
