<?php
// Set the response content type to JSON
header('Content-Type: application/json');

// Database connection parameters
$hostname = "localhost";
$username = "root";
$pass = "";
$db = "ai";

// Create a database connection
$conn = new mysqli($hostname, $username, $pass, $db);

// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize response array
$response = [];

// Check for a valid POST request with 'patient_id' parameter
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['patient_id'])) {
    $patient_id = $_POST['patient_id'];

    // Prepare and execute the SQL query
    $stmt = $conn->prepare("SELECT papp_scan, hcg_scan, nt_scan, fetal_echo, fetal_doppler, anomly_scan, growth_scan1, growth_scan2 ,growth_scan3  FROM scan WHERE patient_id = ?");
    
    // Check for errors in the prepare statement
    if (!$stmt) {
        $response["status"] = "error";
        $response["error"] = "Error in SQL query: " . $conn->error;
    } else {
        $stmt->bind_param("s", $patient_id);
        
        // Execute the statement
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            
            // Check if any rows were returned
            if ($result->num_rows > 0) {
                // Fetch data and construct response
                $row = $result->fetch_assoc();
                $response["status"] = "success";
                $response["data"] = [];
                
                // Check each scan type and add to response if not null
                if ($row['papp_scan'] !== null) {
                    $response["data"]["pappScan"] = $row['papp_scan'];
                }
                if ($row['hcg_scan'] !== null) {
                    $response["data"]["hcgScan"] = $row['hcg_scan'];
                }
                if ($row['nt_scan'] !== null) {
                    $response["data"]["ntScan"] = $row['nt_scan'];
                }
                if ($row['fetal_echo'] !== null) {
                    $response["data"]["fetalEcho"] = $row['fetal_echo'];
                }
                if ($row['fetal_doppler'] !== null) {
                    $response["data"]["fetalDoppler"] = $row['fetal_doppler'];
                }
                if ($row['anomly_scan'] !== null) {
                    $response["data"]["anomalyScan"] = $row['anomly_scan'];
                }
                if ($row['growth_scan1'] !== null) {
                    $response["data"]["growthScan1"] = $row['growth_scan1'];
                }
                if ($row['growth_scan2'] !== null) {
                    $response["data"]["growthScan2"] = $row['growth_scan2'];
                }
                if ($row['growth_scan3'] !== null) {
                    $response["data"]["growthScan3"] = $row['growth_scan3'];
                }
            } else {
                // No rows found for the given patient_id
                $response["status"] = "error";
                $response["error"] = "No scan report found for the given patient ID.";
            }
        } else {
            // Error executing the statement
            $response["status"] = "error";
            $response["error"] = "Error executing SQL statement: " . $stmt->error;
        }
    }
} else {
    // Invalid request
    $response["status"] = "error";
    $response["error"] = "Invalid request. Please provide a valid 'patient_id' parameter in a POST request.";
}

// Close the database connection
$conn->close();

// Send the JSON response
echo json_encode($response);
?>
