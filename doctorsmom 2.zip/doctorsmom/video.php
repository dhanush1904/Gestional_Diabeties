<?php
// Set the response content type to JSON
header('Content-Type: application/json');

// Database connection parameters
$hostname = "localhost";
$username = "root";
$pass = "";
$db = "ai";

// Base URL for constructing full URLs
$baseUrl = "http://192.168.73.173/doctorsmom/"; // Replace with your actual domain and path

// Create a database connection
$conn = new mysqli($hostname, $username, $pass, $db);

// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize response array
$response = [];

// Prepare and execute the SQL query
$stmt = $conn->prepare("SELECT exercise_name, video_description, video_url FROM videos");
if ($stmt) {
    // Execute the statement
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        
        // Initialize an array to store video data
        $videos = [];
        
        while ($row = $result->fetch_assoc()) {
            // Construct full URL for video
            $full_video_url = $baseUrl . $row['video_url'];

            // Append video data to videos array
            $video = [
                "videoName" => $row['exercise_name'],
                "videoDescription" => $row['video_description'],
                "videoUrl" => $full_video_url
            ];
            
            $videos[] = $video;
        }
        
        // Prepare response array
        $response = [
            "status" => "success",
            "data" => $videos
        ];
        
        // Free result set
        $result->free();
    } else {
        // Error in execution
        $response["status"] = "error";
        $response["error"] = "Error in executing SQL query: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();
} else {
    // Error in preparing the statement
    $response["status"] = "error";
    $response["error"] = "Error in SQL query: " . $conn->error;
}

// Close the database connection
$conn->close();

// Send the JSON response
echo json_encode($response);
?>
