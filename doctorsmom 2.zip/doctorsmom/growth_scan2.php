<?php
// Set the content type of the response to JSON
header('Content-Type: application/json');

// Include the database configuration file
include("config.php");

// Enable error reporting and display errors for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Directory where uploaded images will be stored
$uploadDir = "uploads/";

// Initialize response array
$response = [];

// Function to handle uploading of images
function uploadImages($field_name, $uploadDir) {
    $result = [];

    // Check if the file field is set and if it's an array (multiple files)
    if (isset($_FILES[$field_name]) && is_array($_FILES[$field_name]["name"])) {
        foreach ($_FILES[$field_name]["name"] as $key => $value) {
            $targetFile = $uploadDir . basename($_FILES[$field_name]["name"][$key]);
            // Attempt to move the uploaded file to the specified directory
            if (move_uploaded_file($_FILES[$field_name]["tmp_name"][$key], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null; // If upload fails, add null to the result array
            }
        }
    } elseif (isset($_FILES[$field_name])) { // If only one file is uploaded
        $targetFile = $uploadDir . basename($_FILES[$field_name]["name"]);
        if (move_uploaded_file($_FILES[$field_name]["tmp_name"], $targetFile)) {
            $result[] = $targetFile;
        } else {
            $result[] = null;
        }
    }

    return $result;
}

// Check if it's a POST request and if the required fields are set
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['growth_scan2']) && isset($_POST['patient_id'])) {
    // Extract data from the POST request
    $patient_id = $_POST['patient_id'];
    // Call the function to upload images
    $imagePaths = uploadImages('growth_scan2', $uploadDir); 
    foreach($imagePaths as $uploadPath) {
        if($uploadPath) { // If upload was successful
            // Check if patient ID exists in the database
            $sql_select = "SELECT * FROM scan WHERE patient_id = ?";
            $stmt_select = $conn->prepare($sql_select);
            $stmt_select->bind_param('s', $patient_id);
            $stmt_select->execute();
            $result_select = $stmt_select->get_result();
            
            if($result_select->num_rows > 0) {
                // Patient ID exists, update the record
                $sql_update = "UPDATE scan SET growth_scan2 = ? WHERE patient_id = ?";
                $stmt_update = $conn->prepare($sql_update);
                $stmt_update->bind_param('ss', $uploadPath, $patient_id);
                if (!$stmt_update->execute()) {
                    // If execution fails, retrieve error information
                    $response['success'] = false;
                    $response['message'] = 'Error updating image details in the database: ' . $stmt_update->error;
                    echo json_encode($response);
                    return; // Exit the script
                }
            } else {
                // Patient ID doesn't exist, insert a new record
                $sql_insert = "INSERT INTO scan (patient_id, growth_scan2) VALUES (?, ?)";
                $stmt_insert = $conn->prepare($sql_insert);
                $stmt_insert->bind_param('ss', $patient_id, $uploadPath);
                if (!$stmt_insert->execute()) {
                    // If execution fails, retrieve error information
                    $response['success'] = false;
                    $response['message'] = 'Error inserting image details into the database: ' . $stmt_insert->error;
                    echo json_encode($response);
                    return; // Exit the script
                }
            }
        } else {
            // If upload fails, return an error message
            $response['success'] = false;
            $response['message'] = 'Error uploading one or more image files.';
            echo json_encode($response);
            return; // Exit the script
        }
    }
    // If everything is successful, return a success message
    $response['success'] = true;
    $response['message'] = 'Image details updated in the database successfully.';
    echo json_encode($response);
} else {
    // If the request is invalid, return an error message
    $response['success'] = false;
    $response['error'] = 'Invalid request. Please make sure you are sending a POST request with all required fields and including an "image" file.';
    echo json_encode($response);
}
?>
