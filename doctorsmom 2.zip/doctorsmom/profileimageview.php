<?php
// Set the response content type to JSON
header('Content-Type: application/json');

// Database connection parameters
$hostname = "localhost";
$username = "root";
$pass = "";
$db = "ai";

$conn = new mysqli($hostname, $username, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize response array
$response = [];

// Check for a valid POST request with 'patient_id' parameter
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['patient_id'])) {
    $patient_id = $_POST['patient_id'];

    // Prepare and execute the SQL query
    $stmt = $conn->prepare("SELECT patient_profile FROM adddetailspatient WHERE patient_id = ?");
    
    // Check for errors in the prepare statement
    if (!$stmt) {
        $response["status"] = "error";
        $response["error"] = "Error in SQL query: " . $conn->error;
    } else {
        $stmt->bind_param("s", $patient_id);
        
        // Execute the statement
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            
            // Check if any rows were returned
            if ($result->num_rows > 0) {
                // Fetch data and construct response
                $row = $result->fetch_assoc();
                $response["status"] = "success";
                $response["data"] = [
                    "patient_profile" => $baseUrl . $row['patient_profile']
                    
                ];
            } else {
                // No rows found for the given patient_id
                $response["status"] = "error";
                $response["error"] = "No adddetailspatient report found for the given patient ID.";
            }
        } else {
            // Error executing the statement
            $response["status"] = "error";
            $response["error"] = "Error executing SQL statement: " . $stmt->error;
        }
    }
} else {
    // Invalid request
    $response["status"] = "error";
    $response["error"] = "Invalid request. Please provide a valid 'patient_id' parameter in a POST request.";
}

// Close the database connection
$conn->close();

// Send the JSON response
echo json_encode($response);
?>