<?php
// Include the database configuration file
require 'config.php';

// Function to insert data into the 'yes1' table
function insertData($id, $drugname, $dosage, $frequency, $conn) {
    $sql = "INSERT INTO yes1 (`id`, `drugname`, `dosage`, `frequency`) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $id, $drugname, $dosage, $frequency);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

// Function to update data in the 'yes1' table
function updateData($id, $drugname, $dosage, $frequency, $conn) {
    $sql = "UPDATE yes1 SET `drugname`=?, `dosage`=?, `frequency`=? WHERE `id`=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $drugname, $dosage, $frequency, $id);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

// Function to delete data from the 'yes1' table
function deleteData($id, $conn) {
    $sql = "DELETE FROM yes1 WHERE `id`=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

// Check if data is received via POST, PUT, or DELETE request
if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'PUT' || $_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Get the JSON data from the request body
    $json_data = file_get_contents('php://input');

    // Decode the JSON data
    $data = json_decode($json_data, true);

    // Check if the JSON decoding was successful and if all required keys exist
    if ($data !== null && isset($data['id'], $data['drugname'], $data['dosage'], $data['frequency'])) {
        // Extract data from the JSON
        $id = $data['id'];
        $drugname = $data['drugname'];
        $dosage = $data['dosage'];
        $frequency = $data['frequency'];

        // Check the request method and perform the appropriate action
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Insert data into the yes1 table
            if (insertData($id, $drugname, $dosage, $frequency, $conn)) {
                echo json_encode(array("message" => "Data inserted successfully"));
            } else {
                echo json_encode(array("message" => "Error inserting data"));
            }
        } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            // Update data in the yes1 table
            if (updateData($id, $drugname, $dosage, $frequency, $conn)) {
                echo json_encode(array("message" => "Data updated successfully"));
            } else {
                echo json_encode(array("message" => "Error updating data"));
            }
        } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            // Delete data from the yes1 table
            if (deleteData($id, $conn)) {
                echo json_encode(array("message" => "Data deleted successfully"));
            } else {
                echo json_encode(array("message" => "Error deleting data"));
            }
        }
    } else {
        echo json_encode(array("message" => "Invalid or incomplete JSON data"));
    }
} else {
    // Fetch data from the 'yes1' table
    $sql = "SELECT * FROM yes1";
    $result = $conn->query($sql);

    // Check if there are rows in the result
    if ($result->num_rows > 0) {
        // Initialize an array to hold the data
        $data = array();

        // Fetch each row and add it to the data array
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        // Encode the entire data array as JSON and output it
        echo json_encode($data);
    } else {
        // Output a message if no rows are found
        echo json_encode(array("message" => "No data found"));
    }

    // Set the Content-Type header to indicate that JSON is being sent
    header("Content-Type: application/json");
}
?>
