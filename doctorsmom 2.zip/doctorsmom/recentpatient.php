<?php
// Set the response content type to JSON
header('Content-Type: application/json');

// Database connection parameters
$hostname = "localhost";
$username = "root";
$pass = "";
$db = "ai";


// Create a database connection
$conn = new mysqli($hostname, $username, $pass, $db);

// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch the most recently added 100000 patients with status and patient_id
function fetchRecentPatients($conn) {
    // Check if the connection is valid
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch the most recently added 100000 patients with status and patient_id
    $sql = "SELECT patient_id, name, age, patient_profile FROM adddetailspatient ORDER BY patient_id DESC LIMIT 100000";
    $result = $conn->query($sql);

    // Check for SQL query execution errors
    if (!$result) {
        die("Error executing query: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        // Initialize an empty array to store fetched data
        $data = array();

        // Loop through each row of the result
        while ($row = $result->fetch_assoc()) {
            // Modify patient_profile to contain the full URL
            $row['patient_profile'] = $baseUrl . $row['patient_profile'];

            // Add each row to the data array
            $data[] = $row;
        }

        // Encode the entire data array as JSON
        $json_output['status'] = true;
        $json_output["data"] = $data;

        // Output the JSON response
        echo json_encode($json_output);
    } else {
        // Output a message if no rows are found
        echo json_encode(array("status" => true, "message" => "No recent patients found"));
    }
}

// Set the Content-Type header to indicate that JSON is being sent
header("Content-Type: application/json");

// Check if the request method is GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch most recently added 100000 patients with status and patient_id
    fetchRecentPatients($conn);
} else {
    // Output a message if the request method is not GET
    echo json_encode(array("status" => false, "message" => "Invalid request method"));
}
?>
