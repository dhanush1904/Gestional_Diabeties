<?php

// Include the configuration file
require 'config.php';

// Set the content type header
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Get form data from the request
$patient_id = isset($_GET['patient_id']) ? $_GET['patient_id'] : '';
$uploadedFiles = array();

// Define upload directory
$uploadDir = '/xampp/htdocs/uploads/';

// Save each image file
$imageFiles = array(
    'papp_scan',
    'hcg_scan',
    'nt_scan',
    'fetal_echo',
    'fetal_doppler',
    'anomaly_scan',
    'growth_scan',
);

foreach ($imageFiles as $scanType) {
    if (isset($_FILES[$scanType]) && $_FILES[$scanType]['error'] === UPLOAD_ERR_OK) {
        // Get file extension
        $fileExtension = pathinfo($_FILES[$scanType]['name'], PATHINFO_EXTENSION);
        
        // Generate unique filename
        $imageFilename = $uploadDir . $patient_id . '_' . $scanType . '.' . $fileExtension;
        
        // Move uploaded file to destination directory
        if (move_uploaded_file($_FILES[$scanType]['tmp_name'], $imageFilename)) {
            $uploadedFiles[$scanType] = $imageFilename;
        } else {
            // If file upload fails, return error response
            $response = array('status' => 'error', 'message' => 'Error uploading ' . $scanType);
            echo json_encode($response);
            exit();
        }
    }
}

// Database connection
$mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check if connection was successful
if ($mysqli->connect_errno) {
    $response = array('status' => 'error', 'message' => 'Failed to connect to MySQL: ' . $mysqli->connect_error);
    echo json_encode($response);
    exit();
}

// Insert data into the database
$sql = "INSERT INTO scan_report (patient_id, papp_scan, hcg_scan, nt_scan, fetal_echo, fetal_doppler, anomaly_scan, growth_scan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $mysqli->prepare($sql);

// Check if statement preparation was successful
if ($stmt) {
    $stmt->bind_param('ssssssss', $patient_id, $uploadedFiles['papp_scan'], $uploadedFiles['hcg_scan'], $uploadedFiles['nt_scan'], $uploadedFiles['fetal_echo'], $uploadedFiles['fetal_doppler'], $uploadedFiles['anomaly_scan'], $uploadedFiles['growth_scan']);

    // Execute the statement
    if ($stmt->execute()) {
        $response = array('status' => 'success', 'message' => 'Record inserted or updated successfully');
        echo json_encode($response);
    } else {
        // If execution fails, return error response
        $response = array('status' => 'error', 'message' => 'Error executing query: ' . $stmt->error);
        echo json_encode($response);
    }

    // Close the statement
    $stmt->close();
} else {
    // If statement preparation fails, return error response
    $response = array('status' => 'error', 'message' => 'Error preparing statement: ' . $mysqli->error);
    echo json_encode($response);
}

// Close the database connection
$mysqli->close();
?>
