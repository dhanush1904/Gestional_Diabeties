<?php
include("config.php");

// Initialize the response array
$response = array();

// Get data from POST request
$patient_id = $_POST['patient_id'];
$drugname = $_POST['drugname'];
$dosage = $_POST['dosage'];
$frequency = $_POST['frequency'];

// Insert data into yes1 table
$stmt = $conn->prepare("INSERT INTO `yes1` (`patient_id`, `drugname`, `dosage`, `frequency`) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $patient_id, $drugname, $dosage, $frequency);

if ($stmt->execute()) {
    $response['success'] = true;
    $response['message'] = "Data inserted successfully";
} else {
    $response['success'] = false;
    $response['message'] = "Error: " . $stmt->error;
}
$stmt->close();

// Return response as JSON
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();

?>
