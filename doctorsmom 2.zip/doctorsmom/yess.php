<?php
include("config.php");

// Initialize the response array
$response = array();

// Check if patient_id is provided in the GET request
if(isset($_GET['patient_id'])) {
    // Fetch patient_id from GET request
    $patient_id = $_GET['patient_id'];

    // Prepare and bind the query using prepared statements to avoid SQL injection
    $stmt = $conn->prepare("SELECT drugname, dosage, frequency FROM `yes1` WHERE `patient_id` = ?");
    $stmt->bind_param("s", $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the query was successful
    if ($result) {
        // Initialize an array to store the fetched data
        $data = array();
        while ($row = $result->fetch_assoc()) {
            // Add each row to the data array
            $data[] = $row;
        }
        $response['success'] = true;
        $response['message'] = "Data retrieved successfully";
        $response['data'] = $data; // Add the fetched data to the response
    } else {
        // If the query was not successful, set appropriate error message
        $response['success'] = false;
        $response['message'] = "Error: " . $conn->error;
    }
} else {
    // If patient_id is not provided in the GET request
    $response['success'] = false;
    $response['message'] = "Error: patient_id is missing in the request.";
}

// Return response as JSON
header('Content-Type: application/json');
echo json_encode($response);

// Close the prepared statement
$stmt->close();

// Close the database connection
$conn->close();
?>
