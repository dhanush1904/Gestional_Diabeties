<?php
include("config.php");

// Initialize the response array
$response = array();

// Get values from POST request (assuming you're using the POST method)
$name = $_POST['name'];
$create_new_password = $_POST['create_new_password'];
$password = $_POST['password'];
$patient_id = $_POST['patient_id'];

// Check if the patient_id already exists
$checkQuery = "SELECT * FROM patientid WHERE patient_id = '$patient_id'";
$checkResult = $conn->query($checkQuery);

if ($checkResult->num_rows > 0) {
    // Patient_id already exists, return an error
    $response['success'] = false;
    $response['message'] = "Error: Patient_id already exists";
} else {
    // Patient_id doesn't exist, proceed with the insertion
    $sql = "INSERT INTO patientid (name, password, patient_id) VALUES ('$name', '$password', '$patient_id')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        // Success message in boolean format
        $response['success'] = true;
        $response['message'] = "Data inserted successfully";
    } else {
        // Error message in boolean format
        $response['success'] = false;
        $response['message'] = "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
