<?php
header('Content-Type: application/json');

$hostname = "localhost";
$username = "root";
$pass = "";
$db = "ai";

$conn = new mysqli($hostname,$username,$pass,$db);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if image file is selected
if(isset($_FILES["file"])) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["file"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // Check if file already exists
    if (file_exists($target_file)) {
        echo json_encode(array("status" => "error", "message" => "Sorry, file already exists."));
        exit;
    }

    // Check file size
    if ($_FILES["file"]["size"] > 500000) {
        echo json_encode(array("status" => "error", "message" => "Sorry, your file is too large."));
        exit;
    }

    // Allow only certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        echo json_encode(array("status" => "error", "message" => "Sorry, only JPG, JPEG, PNG & GIF files are allowed."));
        exit;
    }

    // Upload file
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        // Insert into database
        $image_name = basename($_FILES["file"]["name"]);
        $image_path = $target_file;
        $sql = "INSERT INTO uploaded_images (image_name, image_path) VALUES ('$image_name', '$image_path')";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(array("status" => "success", "message" => "The file ". htmlspecialchars( basename( $_FILES["file"]["name"])). " has been uploaded."));
        } else {
            echo json_encode(array("status" => "error", "message" => "Error: " . $sql . "<br>" . $conn->error));
        }
    } else {
        echo json_encode(array("status" => "error", "message" => "Sorry, there was an error uploading your file."));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "No file selected."));
}

// Close connection
$conn->close();
?>
