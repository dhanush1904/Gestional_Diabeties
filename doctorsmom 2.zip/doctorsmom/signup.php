<?php
header('Content-Type: application/json');

// Include the database connection configuration
include("config.php");

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = isset($_POST['name']) ? $_POST['name'] : null;
    $doctor_id = isset($_POST['doctor_id']) ? $_POST['doctor_id'] : null;
    $password = isset($_POST['password']) ? $_POST['password'] : null;
    $Mobile_Number = isset($_POST['Mobile_Number']) ? $_POST['Mobile_Number'] : null;

    try {
        // Check if the doctor_id or Mobile_Number already exists
        $checkUserQuery = "SELECT * FROM user WHERE doctor_id = ? OR Mobile_Number = ?";
        $checkStmt = $conn->prepare($checkUserQuery);

        if (!$checkStmt) {
            throw new Exception("Error preparing query: " . $conn->error);
        }

        $checkStmt->bind_param('ss', $doctor_id, $Mobile_Number);
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows > 0) {
            $response['success'] = false;
            $response['message'] = "Doctor ID or mobile number already exists. Please choose different credentials.";
        } else {
            // Hash the password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert user data into the database
            $insertQuery = "INSERT INTO user (name, doctor_id, password, Mobile_Number) VALUES (?, ?, ?, ?)";
            $insertStmt = $conn->prepare($insertQuery);

            if (!$insertStmt) {
                throw new Exception("Error preparing query: " . $conn->error);
            }

            $insertStmt->bind_param('ssss', $name, $doctor_id, $hashedPassword, $Mobile_Number);

            if ($insertStmt->execute()) {
                $response['success'] = true;
                $response['message'] = "User registration successful!";
            } else {
                throw new Exception("Error executing query: " . $insertStmt->error);
            }
        }
    } catch (Exception $e) {
        $response['success'] = false;
        $response['message'] = $e->getMessage();
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

// Close the database connection
$conn->close();

echo json_encode($response);
?>
