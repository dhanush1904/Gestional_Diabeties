<?php
// Include the database configuration file
include("config.php");

// Initialize the response array
$response = array();

// Check if the request is a GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    // Check if the patient_id parameter is provided in the GET request
    if(isset($_GET['patient_id'])) {
        $patient_id = $_GET['patient_id'];

        // Prepare and execute the SQL query to retrieve data from the first table
        $sql1 = "SELECT patient_id, name, age, height, weight,bmi,birthweightpregnancy,chronic, familyhistory,lmp, gestionalage FROM `adddetailspatient` WHERE `patient_id` = '$patient_id'";
        $result1 = $conn->query($sql1);

        // Prepare and execute the SQL query to retrieve data from the second table
        $sql2 = "SELECT  Hba1c, sugar, protien FROM `labtest` WHERE `patient_id` = '$patient_id'";
        $result2 = $conn->query($sql2);

        // Check if data is found in both tables
        if ($result1->num_rows > 0 && $result2->num_rows > 0) {
            // Fetch data from the result sets and store them in arrays
            $data1 = array();
            while($row = $result1->fetch_assoc()) {
                $data1[] = $row;
            }

            $data2 = array();
            while($row = $result2->fetch_assoc()) {
                $data2[] = $row;
            }

            // Combine the data from both tables into a single array
            $combined_data = array(
                'adddetailspatient_data' => $data1,
                'labtest_data' => $data2
            );

            // Set success response with the combined data
            $response['success'] = true;
            $response['data'] = $combined_data;
        } else {
            // Set error response if no data found for the provided patient ID in either table
            $response['success'] = false;
            $response['message'] = 'No data found for the provided patient ID in either table';
        }
    } else {
        // Set error response if patient_id parameter is not provided
        $response['success'] = false;
        $response['message'] = 'Patient ID parameter is required';
    }
} else {
    // Set error response for invalid request method
    $response['success'] = false;
    $response['message'] = 'Invalid request method';
}

// Close the database connection
$conn->close();

// Send the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
