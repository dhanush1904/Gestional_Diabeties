<?php
// Set the response content type to JSON
header('Content-Type: application/json');

// Database connection parameters
$hostname = "localhost";
$username = "root";
$pass = "";
$db = "ai";

// Create a database connection
$conn = new mysqli($hostname, $username, $pass, $db);

// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize response array
$response = [];

// Check for a valid POST request with 'doctorid' parameter
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['doctorid'])) {
    $doctorid = $_POST['doctorid'];

    // Prepare and execute the SQL query
    $stmt = $conn->prepare("SELECT doctor_profile FROM doctorID WHERE doctorid = ?");
    
    // Check for errors in the prepare statement
    if (!$stmt) {
        $response["status"] = "error";
        $response["error"] = "Error in SQL query: " . $conn->error;
    } else {
        $stmt->bind_param("s", $doctorid);
        
        // Execute the statement
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            
            // Check if any rows were returned
            if ($result->num_rows > 0) {
                // Fetch data and construct response
                $row = $result->fetch_assoc();
                $response["status"] = "success";
                $response["data"] = [
                    "doctor_profile" => $row['doctor_profile']
                ];
            } else {
                // No rows found for the given doctorid
                $response["status"] = "error";
                $response["error"] = "No doctorID report found for the given patient ID.";
            }
        } else {
            // Error executing the statement
            $response["status"] = "error";
            $response["error"] = "Error executing SQL statement: " . $stmt->error;
        }
    }
} else {
    // Invalid request
    $response["status"] = "error";
    $response["error"] = "Invalid request. Please provide a valid 'doctorid' parameter in a POST request.";
}

// Close the database connection
$conn->close();

// Send the JSON response
echo json_encode($response);
?>
