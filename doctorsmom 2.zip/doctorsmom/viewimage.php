<?php
require 'config.php';
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Process image upload
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $patient_id = $_POST['patient_id'];

  $target_dir = "uploads/";
  $upload_success = true;

  $scan_types = ['papp_scan', 'hcg_scan', 'nt_scan', 'fetal_echo', 'fetal_doppler', 'anomaly_scan', 'growth_scan'];

  foreach ($scan_types as $scan_type) {
    $target_file = $target_dir . basename($_FILES[$scan_type]["name"]);
    if (move_uploaded_file($_FILES[$scan_type]["tmp_name"], $target_file)) {
      $sql = "UPDATE `scan_report` SET `$scan_type` = '$target_file' WHERE `patient_id` = $patient_id";
      if (!$conn->query($sql)) {
        $upload_success = false;
        break;
      }
    } else {
      $upload_success = false;
      break;
    }
  }

  if ($upload_success) {
    echo "Files uploaded successfully.";
  } else {
    echo "Error uploading files.";
  }
}
?>