<?php
// Set the response content type to JSON
header('Content-Type: application/json');

// Database connection parameters
$hostname = "localhost";
$username = "root";
$pass = "";
$db = "ai";

// Create a database connection
$conn = new mysqli($hostname, $username, $pass, $db);

$uploadDir = "uploads/";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['papp_scan']) && isset($_FILES['hcg_scan']) && isset($_FILES['nt_scan']) && isset($_FILES['fetal_echo']) && isset($_FILES['fetal_doppler']) && isset($_FILES['anomly_scan']) && isset($_FILES['growth_scan']) && isset($_POST['patient_id'])) {
    $patient_id = $_POST['patient_id'];

    // Define the columns and corresponding file variables
    // $columns = ['papp_scan', 'hcg_scan', 'nt_scan', 'fetal_echo', 'fetal_doppler', 'anomly_scan', 'growth_scan'];
    $columns = ['papp_scan'];
    $fileVariables = ['papp_scan', 'hcg_scan', 'nt_scan', 'fetal_echo', 'fetal_doppler', 'anomly_scan', 'growth_scan'];

    // Insert the new patient ID first
    $stmt = $conn->prepare("INSERT INTO scan (patient_id) VALUES (?)");
    $stmt->bind_param("s", $patient_id);
    if (!$stmt->execute()) {
        echo json_encode(["error" => "Error inserting new patient ID: " . $conn->error]);
        exit;
    }

    for ($i = 0; $i < count($columns); $i++) {
        $column = $columns[$i];
        $fileVariable = $fileVariables[$i];

        if (isset($_FILES[$fileVariable])) {
            $file = $_FILES[$fileVariable];
            $fileName = basename($file['name']);
            $uploadPath = $uploadDir . $fileName;

            // Move the uploaded file to the upload directory
            if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
                // Use $conn instead of $pdo
                $stmt = $conn->prepare("UPDATE scan SET $column = ? WHERE patient_id = ?");
                $stmt->bind_param("ss", $uploadPath, $patient_id); // Assuming 'patient_id' is a string
                if ($stmt->execute()) {
                    echo json_encode(["message" => "$column image uploaded successfully."]);
                } else {
                    // Updated error reporting for mysqli
                    echo json_encode(["error" => "Error uploading $column image: " . $conn->error]);
                }
            } else {
                echo json_encode(["error" => "Error uploading the $column image file."]);
            }
        }
    }
} else {
    echo json_encode(["error" => "Invalid request. Please make sure you are sending a POST request with all required fields and including images for the specified columns."]);
}

// No need to nullify $conn if you might use it later in the script
// $conn = null;
?>