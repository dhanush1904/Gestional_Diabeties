<?php
// Include the database configuration file
include("config.php");

// Initialize the response array
$response = array();

// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Assuming you have already established a database connection
    
    // Extract the value of doctorid from the GET parameters
    $doctorid = $_GET['doctorid'] ?? '';

    // Validate and sanitize the doctorid if necessary

    // Construct the SQL SELECT statement
    $sql = "SELECT `doctorid`, `name`, `degree`, `specialist`, `hospitalname` FROM `doctorID` WHERE doctorID = '$doctorid'";

    // Perform the query
    $result = mysqli_query($conn, $sql);

    // Check if the query was successful
    if ($result) {
        // Check if any rows were returned
        if (mysqli_num_rows($result) > 0) {
            // Fetch data from the result set
            $row = mysqli_fetch_assoc($result);

            // Populate the response array with the fetched data
            $response['success'] = true;
            $response['data'] = $row;
        } else {
            // No rows found with the given doctorid
            $response['success'] = false;
            $response['error'] = "No doctor found with the provided ID.";
        }
    } else {
        // Error in executing the SQL query
        $response['success'] = false;
        $response['error'] = "Error: " . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    // Invalid request method
    $response['success'] = false;
    $response['error'] = "Invalid request method.";
}

// Convert the response array to JSON and output it
echo json_encode($response);
?>
