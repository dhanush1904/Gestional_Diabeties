<?php
// Include the database configuration file
require 'config.php';

// Function to insert data into the 'doctor_report' table
function insertData($patient_id, $scanname, $suggestion, $date, $conn) {
    $sql = "INSERT INTO doctor_report (patient_id, scan_name, suggestion, date) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $patient_id, $scanname, $suggestion, $date);

    if ($stmt->execute()) {
        return true;
    } else {
        // Log error if execution fails
        error_log("Error executing SQL: " . $stmt->error);
        return false;
    }
}

// Initialize the response array
$response = array();

// Check if data is received via POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set in the POST data
    if (isset($_POST['patient_id'], $_POST['scan_name'], $_POST['suggestion'], $_POST['date'])) {
        // Extract data from the POST request
        $patient_id = $_POST['patient_id'];
        $scanname = $_POST['scan_name'];
        $suggestion = $_POST['suggestion'];
        $date = $_POST['date'];

        // Insert new data
        if (insertData($patient_id, $scanname, $suggestion, $date, $conn)) {
            $response['status'] = true;
            $response['message'] = "Data inserted successfully";
        } else {
            $response['status'] = false;
            $response['message'] = "Error inserting data";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Invalid or incomplete form data";
    }
} else {
    // Handle other types of requests (e.g., GET)
    $response['status'] = false;
    $response['message'] = "Invalid request method";
}

// Return response as JSON
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn->close();
?>
