<?php
// Include the database configuration file
include("config.php");

// Initialize response array
$response = array();

// Check connection
if ($conn->connect_error) {
    $response['success'] = false;
    $response['message'] = "Connection failed: " . $conn->connect_error;
} else {
    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve search term from form
        $search_term = $_POST['search_term'];

        // Prepare SQL statement
        $sql = "SELECT patient_id FROM adddetailspatient WHERE patient_id = '$search_term'";

        // Execute SQL statement
        $result = $conn->query($sql);

        // Check if any results were returned
        if ($result->num_rows > 0) {
            // Patient found
            $row = $result->fetch_assoc();
            $response['success'] = true;
            $response['message'] = "Patient found";
            $response['patient'] = $row; // You can include additional patient data here if needed
        } else {
            // Patient not found
            $response['success'] = false;
            $response['message'] = "No results found";
        }
    } else {
        // Invalid request method
        $response['success'] = false;
        $response['message'] = "Invalid request method";
    }
}

// Close database connection
$conn->close();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
