<?php

$hostname = "localhost";
$username = "root";
$pass = "";
$db = "ai";

$conn = new mysqli($hostname,$username,$pass,$db);

if(!$conn){
    //echo "not connected";
}

else{
    //echo "connected";
}

?>