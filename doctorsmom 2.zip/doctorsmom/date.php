<?php
// Include the database configuration file
include("config.php");

// Initialize the response array
$response = array();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if patient_id is provided in the POST request
    if (isset($_POST['patient_id'])) {
        // Extract data from the POST request
        $patient_id = $_POST['patient_id'];
    
        // Prepare and execute the SQL statement to fetch dates
        $sql = "SELECT date FROM doctor_report WHERE patient_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $patient_id);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if there are rows in the result
        if ($result->num_rows > 0) {
            // Initialize an array to store dates
            $dates = array();

            // Fetch all dates from the result
            while ($row = $result->fetch_assoc()) {
                $dates[] = $row['date'];
            }

            // Construct response
            $response['success'] = true;
            $response['dates'] = $dates;
        } else {
            // No dates found for the provided patient ID
            $response['success'] = false;
            $response['message'] = "No dates found for the provided patient ID";
        }
    } else {
        // Output a message if patient ID is not provided
        $response['success'] = false;
        $response['message'] = "Please provide patient ID";
    }
} else {
    // Output a message if the request method is not POST
    $response['success'] = false;
    $response['message'] = "This endpoint only supports POST requests";
}

// Return response as JSON
header("Content-Type: application/json");
echo json_encode($response);

// Close the database connection
$conn->close();
?>
