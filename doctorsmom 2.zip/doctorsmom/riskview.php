<?php
// Include the database configuration file
include("config.php");

// Initialize the response array
$response = array();

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Check if the patient_id parameter is provided in the POST request
    if(isset($_POST['patient_id'])) {
        $patient_id = $_POST['patient_id'];

        // Prepare and execute the SQL query to retrieve data from the first table
        $sql = "SELECT patient_id, risk FROM `riskview` WHERE `patient_id` = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $patient_id);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if data is found in the table
        if ($result->num_rows > 0) {
            // Fetch data from the result set and store them in an array
            $data1 = array();
            while($row = $result->fetch_assoc()) {
                $data1[] = $row;
            }
            // Set success response with retrieved data
            $response['success'] = true;
            $response['data'] = $data1;
        } else {
            // Set error response if no data found
            $response['success'] = false;
            $response['message'] = 'No data found for the provided patient ID';
        }
        $stmt->close();
    } else {
        // Set error response if patient_id parameter is not provided
        $response['success'] = false;
        $response['message'] = 'Patient ID parameter is required';
    }
} else {
    // Set error response for invalid request method
    $response['success'] = false;
    $response['message'] = 'Invalid request method';
}

// Close the database connection
$conn->close();

// Send the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
