<?php

if ($_SERVER["REQUEST_METHOD"] == "PUT") {
    // Handle PUT request

    $targetDirectory = "uploads/";

    // Ensure the "uploads" directory exists
    if (!file_exists($targetDirectory)) {
        mkdir($targetDirectory, 0777, true);
    }

    // Function to upload image and return the paths
    function uploadImages($fieldName) {
        global $targetDirectory;
        $result = [];

        // Check if the field name exists and if it's an array
        if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
            foreach ($_FILES[$fieldName]["name"] as $key => $value) {
                $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
                if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                    $result[] = $targetFile;
                } else {
                    $result[] = null;
                }
            }
        } elseif (isset($_FILES[$fieldName])) {
            // If there's only one file, treat it as an array
            $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
            if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null;
            }
        }

        return $result;
    }

    // Initialize image path variables
    $imagePath1 = [];
    $imagePath2 = [];
    $imagePath3 = [];
    $imagePath4 = [];
    $imagePath5 = [];
    $imagePath6 = [];
    $imagePath7 = [];
    // Add similar lines for other image paths

    // Upload Image 1
    $imagePath1 = isset($_FILES["papp_scan"]) ? uploadImages("papp_scan") : [];

    // Upload Image 2
    $imagePath2 = isset($_FILES["hcg_scan"]) ? uploadImages("hcg_scan") : [];

    // Upload Image 3
    $imagePath3 = isset($_FILES["nt_scan"]) ? uploadImages("nt_scan") : [];

    // Upload Image 4
    $imagePath4 = isset($_FILES["fetal_echo"]) ? uploadImages("fetal_echo") : [];

    // Upload Image 5
    $imagePath5 = isset($_FILES["fetal_doppler"]) ? uploadImages("fetal_doppler") : [];

    // Upload Image 6
    $imagePath6 = isset($_FILES["anomly_scan"]) ? uploadImages("anomly_scan") : [];

    // Upload Image 7
    $imagePath7 = isset($_FILES["growth_scan"]) ? uploadImages("growth_scan") : [];
    // Add similar lines for other image paths

    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "ai");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // UPDATE if it's a PUT request
    $sql = "UPDATE scan_report 
    SET 
        papp_scan = '" . implode(",", $imagePath1) . "', 
        hcg_scan = '" . implode(",", $imagePath2) . "', 
        nt_scan = '" . implode(",", $imagePath3) . "', 
        fetal_echo = '" . implode(",", $imagePath4) . "', 
        fetal_doppler = '" . implode(",", $imagePath5) . "', 
        anomly_scan = '" . implode(",", $imagePath6) . "', 
        growth_scan = '" . implode(",", $imagePath7) . "'";

    $response = array();
    if ($conn->query($sql) === TRUE) {
        $response["status"] = "success";
        $response["message"] = "Images updated successfully.";
    } else {
        $response["status"] = "error";
        $response["message"] = "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();

    // Encode the response array to JSON and echo it
    echo json_encode($response);
} elseif ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Handle GET request
    // Add your GET request handling logic here

    echo json_encode(array("status" => "success", "message" => "GET request handled."));
} else {
    // Invalid request
    echo json_encode(array("status" => "error", "message" => "Invalid request."));
}
?>
