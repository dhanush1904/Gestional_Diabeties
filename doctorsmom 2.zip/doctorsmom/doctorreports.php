<?php
// Include the database configuration file
include("config.php");

// Initialize the response array
$response = array();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if patient_id and date are provided in the POST request
    if (isset($_POST['patient_id']) && isset($_POST['date'])) {
        // Fetch data from the 'doctor_report' table based on the provided patient ID and date
        $patient_id = $_POST['patient_id'];
        $date = $_POST['date'];
        $sql = "SELECT scan_name, suggestion FROM doctor_report WHERE patient_id = ? AND date = ?";
        $stmt = $conn->prepare($sql);
        
        // Bind parameters
        $stmt->bind_param("ss", $patient_id, $date);
        
        // Execute the statement
        $stmt->execute();
        
        // Get the result
        $result = $stmt->get_result();

        // Check if there are rows in the result
        if ($result->num_rows > 0) {
            // Initialize an array to hold the data
            $data = array();

            // Fetch each row and add it to the data array
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }

            // Construct response
            $response['success'] = true;
            $response['data'] = $data;
        } else {
            // No data found for the provided patient ID and date
            $response['success'] = false;
            $response['message'] = "No data found for the provided patient ID and date";
        }
    } else {
        // Output a message if patient ID or date is not provided
        $response['success'] = false;
        $response['message'] = "Please provide both patient ID and date";
    }
} else {
    // Output a message if the request method is not POST
    $response['success'] = false;
    $response['message'] = "This endpoint only supports POST requests";
}

// Return response as JSON
header("Content-Type: application/json");
echo json_encode($response);

// Close the database connection
$conn->close();
?>
