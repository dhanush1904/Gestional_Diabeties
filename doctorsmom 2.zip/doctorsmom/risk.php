<?php
include("config.php");

// Initialize the response array
$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if patient_id and risk are provided in the POST request
    if (isset($_POST['patient_id']) && isset($_POST['risk'])) {
        // Get the patient_id and risk from the POST request
        $patient_id = $_POST['patient_id'];
        $risk = $_POST['risk'];

        // Check if the patient_id already exists in the database
        $check_stmt = $conn->prepare("SELECT * FROM `riskview` WHERE `patient_id` = ?");
        $check_stmt->bind_param("s", $patient_id);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            // Patient exists, perform update
            $update_stmt = $conn->prepare("UPDATE `riskview` SET `risk` = ? WHERE `patient_id` = ?");
            $update_stmt->bind_param("ss", $risk, $patient_id);

            if ($update_stmt->execute()) {
                // Data updated successfully
                $response['success'] = true;
                $response['message'] = "Data updated successfully.";
            } else {
                // Error updating the data
                $response['success'] = false;
                $response['message'] = "Error: " . $update_stmt->error;
            }

            // Close the update statement
            $update_stmt->close();
        } else {
            // Patient does not exist, perform insert
            $insert_stmt = $conn->prepare("INSERT INTO `riskview` (`patient_id`, `risk`) VALUES (?, ?)");
            $insert_stmt->bind_param("ss", $patient_id, $risk);

            if ($insert_stmt->execute()) {
                // Data inserted successfully
                $response['success'] = true;
                $response['message'] = "Data inserted successfully.";
            } else {
                // Error inserting the data
                $response['success'] = false;
                $response['message'] = "Error: " . $insert_stmt->error;
            }

            // Close the insert statement
            $insert_stmt->close();
        }

        // Close the check statement
        $check_stmt->close();
    } else {
        // patient_id or risk is not provided in the POST request
        $response['success'] = false;
      
    }
} else {
    // Unsupported request method
    $response['success'] = false;
    $response['message'] = "Unsupported request method.";
}

// Return response as JSON
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$conn->close();
?>
