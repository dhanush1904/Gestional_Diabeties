<?php
// Include the database configuration file
require 'config.php';

// Function to insert data into the 'blood' table
function insertData($patient_id, $date, $time, $day, $food, $bloodsugar, $conn) {
    $sql = "INSERT INTO blood (patient_id, date, time, day, food, bloodsugar) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Check for a prepared statement error
    if (!$stmt) {
        die("Error in SQL statement: " . $conn->error);
    }

    $stmt->bind_param("ssssss", $patient_id, $date, $time, $day, $food, $bloodsugar);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

// Check if data is received via POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required form fields are set
    if (isset($_POST['patient_id'], $_POST['date'], $_POST['time'], $_POST['day'], $_POST['food'], $_POST['bloodsugar'])) {
        // Extract data from the form
        $patient_id = $_POST['patient_id'];
        $date = $_POST['date'];
        $time = $_POST['time'];
        $day = $_POST['day'];
        $food = $_POST['food'];
        $bloodsugar = $_POST['bloodsugar'];

        // Insert data into the blood table
        if (insertData($patient_id, $date, $time, $day, $food, $bloodsugar, $conn)) {
            echo json_encode(array("success" => true, "message" => "Data inserted successfully"));
        } else {
            echo json_encode(array("success" => false, "message" => "Error inserting data"));
        }
    } else {
        echo json_encode(array("success" => false, "message" => "Invalid or incomplete form data"));
    }
} else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Check if a specific patient_id is provided
    if (isset($_GET['patient_id'])) {
        $patient_id = $_GET['patient_id'];

        // Fetch data from the 'blood' table for the specific patient_id
        $sql = "SELECT * FROM blood WHERE patient_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $patient_id);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if there are rows in the result
        if ($result->num_rows > 0) {
            // Initialize an array to hold the data
            $data = array();

            // Fetch each row and add it to the data array
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }

            // Encode the entire data array as JSON and output it
            echo json_encode(array("success" => true, "data" => $data));
        } else {
            // Output a message if no rows are found for the specific patient_id
            echo json_encode(array("success" => true, "message" => "No data found for the specified patient_id"));
        }
    } else {
        // Output a message if patient_id is not provided in the GET request
        echo json_encode(array("success" => false, "message" => "Patient_id parameter is missing in the GET request"));
    }
} else {
    // Output a message if the request method is not supported
    echo json_encode(array("success" => false, "message" => "Unsupported request method"));
}

// Set the Content-Type header to indicate that JSON is being sent
header("Content-Type: application/json");
?>
