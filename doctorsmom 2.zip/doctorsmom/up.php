<?php
require 'config.php';

header('Content-Type: application/json');

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['video'])) {
    $uploadsDirectory = 'uploads/';
    $uploadedFile = $uploadsDirectory . basename($_FILES['video']['name']);

    // Collect additional form data
    $exerciseName = $_POST['exercise_name'] ?? '';
    $videoDescription = $_POST['video_description'] ?? '';
  

    if (move_uploaded_file($_FILES['video']['tmp_name'], $uploadedFile)) {
        $filePath = $uploadedFile;

        // Assuming you have a database connection named $conn
        $sql = "INSERT INTO videos (exercise_name, video_description, video_url, duration, process) 
                VALUES (:exercise_name, :video_description, :video_url, :duration, :process)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':exercise_name', $exerciseName);
        $stmt->bindParam(':video_description', $videoDescription);
        $stmt->bindParam(':video_url', $filePath);
        $stmt->bindParam(':duration', $duration);
        $stmt->bindParam(':process', $process);

        if ($stmt->execute()) {
            $baseURL = 'http://172.23.19.15/doctorsmom/';
            $completeURL = $baseURL . $filePath;

            $response['status'] = 'success';
            $response['url'] = $completeURL;
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Error inserting video information into the database';
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Error uploading video.';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request.';
}

// Close the database connection
$conn = null;

// Return the JSON response
echo json_encode($response);
?>