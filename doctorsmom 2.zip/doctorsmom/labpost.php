<?php
include("config.php");

// Initialize the response array
$response = array();

// Get data from POST request
$patient_id = $_POST['patient_id'];
$Hba1c = $_POST['Hba1c'];
$sugar = $_POST['sugar'];
$protien = $_POST['protien'];

// Insert data into labtest table
$sql = "INSERT INTO `labtest`(`patient_id`, `Hba1c`, `sugar`, `protien`) 
        VALUES ('$patient_id', '$Hba1c', '$sugar', '$protien')";

$response = array(); // Initialize response array

if ($conn->query($sql) === TRUE) {
    $response['success'] = true;
    $response['message'] = "data inserted successfully";
} else {
    $response['success'] = false;
    $response['message'] = "Error: " . $sql . "<br>" . $conn->error;
}

// Return response as JSON
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();

?>
