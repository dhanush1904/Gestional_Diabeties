<?php
include("config.php");

// Initialize the response array
$response = array();

// Get the patient_id from the POST request
$patient_id = $_POST['patient_id'];

// Check if the patient_id is provided
if (isset($patient_id)) {
    // Select patient data based on the provided patient_id
    $sql = "SELECT name,patient_id FROM patientid WHERE patient_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if any rows are returned
    if ($result->num_rows > 0) {
        // Fetch data and store it in an associative array
        $row = $result->fetch_assoc();
        
        // Add fetched data to the response array
        $response['success'] = true;
        $response['message'] = "Data retrieved successfully";
        $response['data'] = $row;
    } else {
        // No data found for the provided patient_id
        $response['success'] = false;
        $response['message'] = "No data found for the provided patient ID";
    }
} else {
    // If patient_id is not provided in the request
    $response['success'] = false;
    $response['message'] = "Patient ID is missing in the request";
}

// Close the prepared statement
$stmt->close();

// Close the database connection
$conn->close();

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
