<?php
$conn = new mysqli($hostname,$username,$pass,$db);
$uploadDir = "uploads/";
$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $patient_id = $_POST["patient_id"];

    function uploadImages($fieldName, $targetDirectory) {
        $result = [];

        // Check if the field name exists and if it's an array
        if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
            foreach ($_FILES[$fieldName]["name"] as $key => $value) {
                $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
                if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                    $result[] = $targetFile;
                } else {
                    $result[] = null;
                }
            }
        } elseif (isset($_FILES[$fieldName])) {
            // If there's only one file, treat it as an array
            $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
            if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null;
            }
        }

        return $result;
    }

    // Upload Images
    $imagePaths = isset($_FILES["papp_scan"]) ? uploadImages("papp_scan", $uploadDir) : null;

    if ($imagePaths) {
        foreach ($imagePaths as $imagePath) {
            $insertQuery = "INSERT INTO adddetailspatient (patient_id, papp_scan) VALUES (?, ?)";
            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param("ss", $id, $imagePath);

            if ($stmt->execute()) {
                $response[] = "File path inserted into the database.";
            } else {
                $response[] = "Failed to insert file path into the database.";
            }
            $stmt->close();
        }
    } else {
        $response[] = "No files uploaded.";
    }
} else {
    $response[] = "Invalid request.";
}

$conn->close();
echo json_encode($response);
?>
