<?php

include("config.php"); // Include your database connection configuration

// Initialize the response array
$response = array();

// Check if patient_id is provided in the POST request
if (isset($_POST['patient_id'])) {

    // Sanitize the input to prevent SQL injection
    $patient_id = mysqli_real_escape_string($conn, $_POST['patient_id']);

    // Select data from the database based on the provided patient_id
    $sql = "SELECT date, time, day, weightgain FROM weight WHERE patient_id = '$patient_id'";

    $result = $conn->query($sql);

    if ($result) {
        // Check if any rows were returned
        if ($result->num_rows > 0) {
            // Fetch data and store it in the response array
            $response['success'] = true;
            $response['data'] = array();

            while ($row = $result->fetch_assoc()) {
                // Check if an entry with the same day and date already exists
                $existingEntry = array_filter($response['data'], function ($entry) use ($row) {
                    return $entry['day'] == $row['day'] && $entry['date'] == $row['date'];
                });

                if (empty($existingEntry)) {
                    // If no existing entry, create a new entry
                    $CountData = array(
                        'time' => $row['time'],
                        'weightgain' => $row['weightgain']
                    );

                    $weightHistory = array(
                        'day' => $row['day'],
                        'date' => $row['date'],
                        'isColleps2' => false,  
                        'CountData' => array($CountData)
                    );

                    $response['data'][] = $weightHistory;
                } else {
                    // If entry exists, add CountData to the existing entry
                    $existingEntryKey = key($existingEntry);
                    $CountData = array(
                        'time' => $row['time'],
                        'weightgain' => $row['weightgain']
                    );

                    $response['data'][$existingEntryKey]['CountData'][] = $CountData;
                }
            }
        } else {
            $response['success'] = false;
            $response['message'] = "No data found for the provided patient_id.";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Error executing query: " . $conn->error;
    }
} else {
    $response['success'] = false;
    $response['message'] = "patient_id not provided in the POST request.";
}

// Return response as JSON
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();

?>
