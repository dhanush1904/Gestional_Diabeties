<?php

include("config.php");

$response = array();

if (isset($_POST['patient_id'])) {
    $patient_id = mysqli_real_escape_string($conn, $_POST['patient_id']);

    $sql = "SELECT date, time, day, food, bloodsugar FROM blood WHERE patient_id = '$patient_id'";
    
    $result = $conn->query($sql);

    if (!$result) {
        $response['success'] = false;
        $response['message'] = "Error executing query: " . $conn->error;
    } else {
        if ($result->num_rows > 0) {
            $response['success'] = true;
            $response['data'] = array();

            while ($row = $result->fetch_assoc()) {
                $existingEntry = array_filter($response['data'], function ($entry) use ($row) {
                    return $entry['day'] == $row['day'] && $entry['date'] == $row['date'];
                });

                if (empty($existingEntry)) {
                    $countData = array(
                        'time' => $row['time'],
                        'food' => $row['food'],
                        'bloodsugar' => $row['bloodsugar']
                    );

                    $bloodHistory = array(
                        'day' => $row['day'],
                        'date' => $row['date'],
                        'isColleps1' => false,
                        'countData' => array($countData)
                    );

                    $response['data'][] = $bloodHistory;
                } else {
                    $existingEntryKey = key($existingEntry);
                    $countData = array(
                        'time' => $row['time'],
                        'food' => $row['food'],
                        'bloodsugar' => $row['bloodsugar']
                    );

                    $response['data'][$existingEntryKey]['countData'][] = $countData;
                }
            }
        } else {
            $response['success'] = false;
            $response['message'] = "No data found for the provided patient_id.";
        }
    }
} else {
    $response['success'] = false;
    $response['message'] = "patient_id not provided in the POST request.";
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();

?>
