<?php
include("config.php");

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required form fields are set
    if (isset($_POST['patient_id']) && isset($_POST['password'])) {
        $patient_id = $_POST['patient_id'];
        $password = $_POST['password'];

        // Assuming your config.php file contains the mysqli connection

        // Check the connection
        if ($conn->connect_error) {
            $response['success'] = false;
            $response['message'] = "Connection failed: " . $conn->connect_error;
        } else {
            // Use prepared statements to prevent SQL injection
            $sql = "SELECT * FROM patientid WHERE patient_id = ? AND password = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $patient_id, $password);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Fetch the row from the result
                $row = $result->fetch_assoc();

                $response['success'] = true;
                $response['message'] = "Login successful!";
                $response['patient_id'] = $row['patient_id'];
            } else {
                $response['success'] = false;
                $response['message'] = "Invalid patient_id or password";
            }

            $stmt->close(); // Close the prepared statement
        }
    } else {
        $response['success'] = false;
        $response['message'] = "patient_id and password parameters are required in the form data.";
    }
} else {
    $response['success'] = false;
    $response['message'] = "This endpoint only supports POST requests.";
}

// Close the database connection
$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>
