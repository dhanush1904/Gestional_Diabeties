<?php
include("config.php");

// Initialize the response array
$response = array()

ini_set('display_errors', '1');

// Get form data from the request
$patient_id = isset($_POST['patient_id']) ? $_POST['patient_id'] : '';
$papp_scan = isset($_FILES['papp_scan']) ? $_FILES['papp_scan'] : null;
$hcg_scan = isset($_FILES['hcg_scan']) ? $_FILES['hcg_scan'] : null;
$nt_scan = isset($_FILES['nt_scan']) ? $_FILES['nt_scan'] : null;
$fetal_echo = isset($_FILES['fetal_echo']) ? $_FILES['fetal_echo'] : null;
$fetal_doppler = isset($_FILES['fetal_doppler']) ? $_FILES['fetal_doppler'] : null;
$anomly_scan = isset($_FILES['anomly_scan']) ? $_FILES['anomly_scan'] : null;
$growth_scan = isset($_FILES['growth_scan']) ? $_FILES['growth_scan'] : null;

// Handle replace option
$replaceOption = isset($_POST['replace_option']) ? $_POST['replace_option'] : 'false';
if ($replaceOption == 'true') {
    // Delete existing video files if replace option is true
    $existingVideoFiles = glob('uploads/scans/' . $patient_id . '_*.mp4');
    foreach ($existingVideoFiles as $existingVideoFile) {
        unlink($existingVideoFile);
    }
}

// Handle delete option
$deleteOption = isset($_POST['delete_option']) ? $_POST['delete_option'] : 'false';
if ($deleteOption == 'true') {
    // Delete record from the database if delete option is true
    $mysqli = new mysqli('localhost', 'root', '', 'scans');
    if ($mysqli->connect_error) {
        $response = array('status' => 'error', 'message' => 'Database connection error: ' . $mysqli->connect_error);
        echo json_encode($response);
        exit();
    }

    $deleteSql = "DELETE FROM scan_report WHERE patient_id = '$patient_id'";
    if ($mysqli->query($deleteSql) === true) {
        // Also delete associated video files
        $existingVideoFiles = glob('uploads/scans/' . $patient_id . '_*.mp4');
        foreach ($existingVideoFiles as $existingVideoFile) {
            unlink($existingVideoFile);
        }

        $response = array('status' => 'success', 'message' => 'Record deleted successfully');
        echo json_encode($response);
    } else {
        $response = array('status' => 'error', 'message' => 'Error deleting record: ' . $mysqli->error);
        echo json_encode($response);
    }

    // Close database connection
    $mysqli->close();
    exit; // Exit the script after deleting the record
}

// Save video files to a local directory
$uploadDir = 'uploads/scans/';

// Check if the directory exists, create it if not
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Save each video file
$uploadedFiles = array();
$videoFiles = array(
    'papp_scan' => $papp_scan,
    'hcg_scan' => $hcg_scan,
    'nt_scan' => $nt_scan,
    'fetal_echo' => $fetal_echo,
    'fetal_doppler' => $fetal_doppler,
    'anomly_scan' => $anomly_scan,
    'growth_scan' => $growth_scan,
);

foreach ($videoFiles as $scanType => $videoFile) {
    if ($videoFile && isset($videoFile['tmp_name'])) { // Check if 'tmp_name' is set before using it
        $videoFilename = $uploadDir . $patient_id . '_' . $scanType . '.mp4'; // Assuming the video is in MP4 format

        // Log information about the uploaded file
        error_log($scanType . ' File Info: ' . print_r($videoFile, true));

        // Move the uploaded file to the specified directory
        if (move_uploaded_file($videoFile['tmp_name'], $videoFilename)) {
            $uploadedFiles[$scanType] = $videoFilename;
        } else {
            $uploadedFiles[$scanType] = 'Error uploading ' . $scanType;
        }
    }
}

// Connect to your MySQL database (adjust these parameters accordingly)
$mysqli = new mysqli('localhost', 'root', '', 'scans');

// Check connection
if ($mysqli->connect_error) {
    $response = array('status' => 'error', 'message' => 'Database connection error: ' . $mysqli->connect_error);
    echo json_encode($response);
    exit();
}

// Insert or update data in the database
$sql = "INSERT INTO scan_report (patient_id, papp_scan, hcg_scan, nt_scan, fetal_echo, fetal_doppler, anomly_scan, growth_scan) VALUES (
    '$patient_id',
    '{$uploadedFiles['papp_scan']}',
    '{$uploadedFiles['hcg_scan']}',
    '{$uploadedFiles['nt_scan']}',
    '{$uploadedFiles['fetal_echo']}',
    '{$uploadedFiles['fetal_doppler']}',
    '{$uploadedFiles['anomly_scan']}',
    '{$uploadedFiles['growth_scan']}'
) ON DUPLICATE KEY UPDATE
    papp_scan = VALUES(papp_scan),
    hcg_scan = VALUES(hcg_scan),
    nt_scan = VALUES(nt_scan),
    fetal_echo = VALUES(fetal_echo),
    fetal_doppler = VALUES(fetal_doppler),
    anomly_scan = VALUES(anomly_scan),
    growth_scan = VALUES(growth_scan)";

if ($mysqli->query($sql) === true) {
    $response = array('status' => 'success', 'message' => 'Record inserted or updated successfully');
    echo json_encode($response);
} else {
    $response = array('status' => 'error', 'message' => 'Error: ' . $sql . ' - ' . $mysqli->error);
    echo json_encode($response);
}

$mysqli->close();
header('Content-Type: application/json');


?>