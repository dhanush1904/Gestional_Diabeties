<?php
// Include the database configuration file
include("config.php");

// Initialize the response array
$response = array();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if patient_id and date are provided in the POST request
    if (isset($_POST['patient_id']) && isset($_POST['date'])) {
        // Extract data from the POST request
        $patient_id = $_POST['patient_id'];
        $date = $_POST['date'];

        // Prepare and execute the SQL statement to fetch suggestions
        $sql = "SELECT suggestion FROM doctor_report WHERE patient_id = ? AND date = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $patient_id, $date);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if there are rows in the result
        if ($result->num_rows > 0) {
            // Fetch suggestion from the result
            $row = $result->fetch_assoc();
            $suggestion = $row['suggestion'];

            // Construct response
            $response['success'] = true;
            $response['suggestion'] = $suggestion;
        } else {
            // No suggestion found for the provided patient ID and date
            $response['success'] = false;
            $response['message'] = "No suggestion found for the provided patient ID and date";
        }
    } else {
        // Output a message if patient ID or date is not provided
        $response['success'] = false;
        $response['message'] = "Please provide patient ID and date";
    }
} else {
    // Output a message if the request method is not POST
    $response['success'] = false;
    $response['message'] = "This endpoint only supports POST requests";
}

// Return response as JSON
header("Content-Type: application/json");
echo json_encode($response);

// Close the database connection
$conn->close();
?>
