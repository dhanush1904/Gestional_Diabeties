<?php
// Set the content type of the response to JSON
header('Content-Type: application/json');

// Include the database configuration file
include("config.php");

// Enable error reporting and display errors for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Directory where uploaded images will be stored
$uploadDir = "uploads/";

// Function to handle uploading of images
function uploadImages($field_name, $uploadDir) {
    $result = [];

    // Check if the file field is set and if it's an array (multiple files)
    if (isset($_FILES[$field_name]) && is_array($_FILES[$field_name]["name"])) {
        foreach ($_FILES[$field_name]["name"] as $key => $value) {
            $targetFile = $uploadDir . basename($_FILES[$field_name]["name"][$key]);
            // Attempt to move the uploaded file to the specified directory
            if (move_uploaded_file($_FILES[$field_name]["tmp_name"][$key], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null; // If upload fails, add null to the result array
            }
        }
    } elseif (isset($_FILES[$field_name])) { // If only one file is uploaded
        $targetFile = $uploadDir . basename($_FILES[$field_name]["name"]);
        if (move_uploaded_file($_FILES[$field_name]["tmp_name"], $targetFile)) {
            $result[] = $targetFile;
        } else {
            $result[] = null;
        }
    }

    return $result;
}

// Check if it's a POST request and if the required fields are set
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['image']) && isset($_POST['patient_id'])) {
    // Extract data from the POST request
    $patient_id = $_POST['patient_id'];
    // Call the function to upload images
    $imagePaths = uploadImages('image', $uploadDir); 
    foreach($imagePaths as $uploadPath) {
        if($uploadPath) { // If upload was successful
            // Prepare the SQL query
            $sql = "INSERT INTO scan (patient_id, papp_scan) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            // Bind parameters
            $stmt->bind_param('ss', $patient_id, $uploadPath);
            // Execute the query
            if (!$stmt->execute()) {
                // If execution fails, retrieve error information
                $errorInfo = $stmt->error;
                echo json_encode(["error" => "Error inserting image details into the database: " . $errorInfo]);
                return; // Exit the script
            }
        } else {
            // If upload fails, return an error message
            echo json_encode(["error" => "Error uploading one or more image files."]);
            return; // Exit the script
        }
    }
    // If everything is successful, return a success message
    echo json_encode(["message" => "Image details inserted into the database successfully."]);

} else {
    // If the request is invalid, return an error message
    echo json_encode(["error" => "Invalid request. Please make sure you are sending a POST request with all required fields and including an 'image' file."]);
}
?>
